# Older Translation

**This translation is for an older version of the Tutorial:** <https://github.com/dwyl/learn-to-send-email-via-google-script-html-no-server/blob/133ceb9eb7b3d6ea3205a533ed99468d5feaf7e1/README.es.md>

The code snapshot is there but does not have the latest enhancements. If you would like to use it, be our guest. If you have time to update the translation, please do! We will gladly accept a [Pull Request](https://github.com/dwyl/learn-to-send-email-via-google-script-html-no-server/pulls) with an update.